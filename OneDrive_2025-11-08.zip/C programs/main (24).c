/******************************************************************************
 
WAPC to input an integer. Calculate and display the square and cube of the number.

*******************************************************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   int n;
   int square,cube;
   printf("Enter a number:");
   scanf("%d",&n);
   square = pow(n,2);
   printf("\nThe square value is:%d",square);
   cube = pow(n,3);
   printf("\nThe cube value is:%d",cube);

    return 0;
}