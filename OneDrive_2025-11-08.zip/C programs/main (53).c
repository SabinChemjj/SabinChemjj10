/******************************************************************************
WAPC to input an array of ‘n’ elements from the user. Find and display the second highest element of the array.
*******************************************************************************/

#include <stdio.h>
#include <limits.h>

int main() {
    int n;

    printf("Enter the number of elements in the array: ");
    if (scanf("%d", &n) != 1) {
        printf("Invalid input for the number of elements.\n");
        return 1;
    }

    if (n < 2) {
        printf("Need at least two elements to determine the second highest.\n");
        return 1;
    }

    int arr[n];
    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("Invalid input for array element.\n");
            return 1;
        }
    }

    int highest = INT_MIN;
    int second_highest = INT_MIN;

    for (int i = 0; i < n; i++) {
        if (arr[i] > highest) {
            // New highest found: update second_highest first
            second_highest = highest;
            highest = arr[i];
        } else if (arr[i] > second_highest && arr[i] != highest) {
            // arr[i] is between highest and second_highest (and not equal to highest)
            second_highest = arr[i];
        }
    }

    if (second_highest == INT_MIN) {
        printf("There is no distinct second highest element (all elements might be equal).\n");
    } else {
        printf("The highest element is %d\n", highest);
        printf("The second highest element is %d\n", second_highest);
    }

    return 0;
}
