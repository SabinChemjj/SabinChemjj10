/******************************************************************************
 WAPC to input the age of a person. Check and display if the person is eligible to vote
*******************************************************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   int age;
   printf("Enter age:");
   scanf("%d",&age);
   if(age>=18){
       printf("\nPerson can vote");
   }
   else{
       printf("\nPerson is underage");
   }
    return 0;
}