/******************************************************************************
WAPC to input a number. If it is positive, check if the number is odd or even.
*******************************************************************************/

#include <stdio.h>

int main()
{
   int n;
   printf("Enter number:");
   scanf("%d",&n);
   if(n>=0){
       printf("\nThis is a positive number");
       if(n%2==0){
           printf("\nEven number");
       }
       else{
           printf("\nOdd number");
       }
   }
   else{
       printf("\nThis is a negetive number");
   }
   

    return 0;
}