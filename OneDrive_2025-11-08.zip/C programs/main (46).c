/******************************************************************************
WAPC to input a positive integer from the user. Find and display the number of 
digits in the number, sum of the digits of the number and product of the digits of the number.
*******************************************************************************/

#include <stdio.h>

int main() {
    int number, originalNumber;
    int digitCount = 0, sum = 0, product = 1;
    printf("Enter a positive integer: ");
    scanf("%d", &number);
    if (number <= 0) {
        printf("Invalid input. Please enter a positive integer.\n");
        return 1;
    }
    originalNumber = number; // Save original number for output
    while (number > 0) {
        int digit = number % 10;
        digitCount++;
        sum += digit;
        product *= digit;
        number /= 10;
    }
    printf("Number: %d\n", originalNumber);
    printf("Number of digits: %d\n", digitCount);
    printf("Sum of digits: %d\n", sum);
    printf("Product of digits: %d\n", product);

    return 0;
}
