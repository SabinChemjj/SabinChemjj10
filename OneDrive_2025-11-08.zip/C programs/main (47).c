/******************************************************************************
WAPC to display the first ‘n’ natural numbers where ‘n’ is the user input.
*******************************************************************************/

#include <stdio.h>

int main() {
    int n;
    int i;
    printf("Enter a positive number:");
    scanf("%d",&n);
    if(n<0){
        printf("\nInvalid number");
    }
    for(i=1;i<=n;i++){
        printf("\n%d",i);
    }
    return 0;
}
