/******************************************************************************
WAPC to input a positive integer. Check and print if the number is perfect or not.
Note: Perfect number is a number which is equal to the sum of all its proper divisors
(excluding itself). Example: 28 = 1 + 2 + 4 + 7 + 14

*******************************************************************************/

#include <stdio.h>

int main()
{
   int n ;
   printf("Enter a positive integer:");
   scanf("%d",&n);
   if(n>0){
       printf("\nValid number");
   }
   else{
       printf("\nInvalid number");
   }
   int i;
   int sum=0;
   for(i=1;i<=(n/2);i++){
        if (n % i == 0) {
            sum += i;
        }
   }
   if(sum==n){
       printf("\nThis is a perfect number");
   }
   else{
       printf("\nThis is not a perfect number");
   }
   
   

    return 0;
}