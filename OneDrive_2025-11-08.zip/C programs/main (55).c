/******************************************************************************
WAPC to input two sorted integer arrays from the user. Merge these two arrays into a single sorted array.
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int n1, n2;
    printf("Enter the number of elements in the first sorted array: ");
    if (scanf("%d", &n1) != 1 || n1 < 1) {
        printf("Invalid size.\n");
        return 1;
    }
    int *arr1 = (int*)malloc(n1 * sizeof(int));
    printf("Enter %d elements (in sorted ascending order) for array1:\n", n1);
    for (int i = 0; i < n1; i++) {
        if (scanf("%d", &arr1[i]) != 1) {
            printf("Invalid input.\n");
            free(arr1);
            return 1;
        }
    }

    printf("Enter the number of elements in the second sorted array: ");
    if (scanf("%d", &n2) != 1 || n2 < 1) {
        printf("Invalid size.\n");
        free(arr1);
        return 1;
    }
    int *arr2 = (int*)malloc(n2 * sizeof(int));
    printf("Enter %d elements (in sorted ascending order) for array2:\n", n2);
    for (int i = 0; i < n2; i++) {
        if (scanf("%d", &arr2[i]) != 1) {
            printf("Invalid input.\n");
            free(arr1);
            free(arr2);
            return 1;
        }
    }

    int *merged = (int*)malloc((n1 + n2) * sizeof(int));

    int i = 0, j = 0, k = 0;
    while (i < n1 && j < n2) {
        if (arr1[i] < arr2[j]) {
            merged[k++] = arr1[i++];
        } else {
            merged[k++] = arr2[j++];
        }
    }
    while (i < n1) {
        merged[k++] = arr1[i++];
    }
    while (j < n2) {
        merged[k++] = arr2[j++];
    }

    printf("Merged sorted array:\n");
    for (int idx = 0; idx < n1 + n2; idx++) {
        printf("%d ", merged[idx]);
    }
    printf("\n");

    free(arr1);
    free(arr2);
    free(merged);

    return 0;
}
