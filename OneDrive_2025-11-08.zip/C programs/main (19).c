/******************************************************************************
 
WAPC to input the coordinates of two points (x1, y1) and (x2, y2). Calculate the slope and display the same.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int x1,x2,y1,y2;
    int slope;
    printf("Enter coordinates:");
    scanf("%d",&x1 );
    scanf("%d",&x2 );
    scanf("%d",&y1 );
    scanf("%d",&y2 );
    slope=(y2-y1)/(x2-x1);
    printf("\nThe slope is:%d",slope);
    
    

    return 0;
}