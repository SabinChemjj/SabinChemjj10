/******************************************************************************
WAPC to input a year. Check and print if it is a leap year or not.
*******************************************************************************/

#include <stdio.h>
#include <math.h>

int main()
{
    int year ;
    printf("Enter a year:");
    scanf("%d",&year);
    if(year%100==0){
        if(year%400==0){
            printf("\nThe yaer is a leap year");
        }
        else {
            printf("\nThe year is not a leap year");
        }
    }
    else{
        if(year%4==0){
            printf("\nThe year is a leap year");
        }
        else{
            printf("\n The year is not a leap year");
        }
    }

    
    return 0;
}
