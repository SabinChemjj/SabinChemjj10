/******************************************************************************
WAPC to input a positive integer from the user. Check and print if the number is 
palindrome or not. Note: A palindrome number is a number that remains the same
when its digits are reversed, for example, 121.
*******************************************************************************/

#include <stdio.h>

int main()
{
    int n;
    printf("Enter a number:");
    scanf("%d",&n);
    if(n<0){
        printf("\nThis is a positive number");
    }
    int original = n;
    int reversed = 0;
    int remainder;
    
    while (n != 0) {
        remainder = n % 10;
        reversed = reversed * 10 + remainder;
        n = n / 10;
    }

    if (reversed == original) {
        printf("%d is a palindrome number.\n", original);
    } else {
        printf("%d is not a palindrome number.\n", original);
    }

    return 0;
}