/******************************************************************************
WAPC to display the following series of numbers: 1, 2, 4, 8, …, n-terms. Here, ‘n’ is user input.
*******************************************************************************/

#include <stdio.h>

int main()
{
    int n;
	printf("\nEnter number:");
	scanf("%d",&n);
	int i;
	for(i=1;i<=n; ){
	    i=i*2;
	    printf("\n%d", i);
	}
	

    return 0;
}