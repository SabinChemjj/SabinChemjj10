/******************************************************************************
WAPC to input an integer array from the user. Display the frequency of every element in the array.
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int n;

    printf("Enter number of elements in the array: ");
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Invalid size. Please enter a positive integer.\n");
        return 1;
    }

    int *arr = malloc(n * sizeof(int));
    if (!arr) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    printf("Enter %d integer elements:\n", n);
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            printf("Invalid input.\n");
            free(arr);
            return 1;
        }
    }

    int *freq = malloc(n * sizeof(int));
    if (!freq) {
        printf("Memory allocation failed.\n");
        free(arr);
        return 1;
    }

    for (int i = 0; i < n; i++) {
        freq[i] = -1;
    }

    for (int i = 0; i < n; i++) {
        if (freq[i] == 0) {
            continue;
        }

        int count = 1;
        for (int j = i + 1; j < n; j++) {
            if (arr[i] == arr[j]) {
                count++;
                freq[j] = 0;
            }
        }
        
        freq[i] = count;
    }

    printf("\nFrequency of each distinct element in the array:\n");
    for (int i = 0; i < n; i++) {
        if (freq[i] != 0) {
            printf("%d occurs %d %s\n",
                   arr[i],
                   freq[i],
                   (freq[i] == 1 ? "time" : "times"));
        }
    }

    free(arr);
    free(freq);
    return 0;
}
