/******************************************************************************
WAPC to input an integer array from the user. Remove all duplicates and display the resultant array.
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main() {
    int n;
    printf("Enter number of elements in the array: ");
    if (scanf("%d", &n) != 1 || n < 1) {
        printf("Invalid size. Must be ≥ 1.\n");
        return 1;
    }

    int *arr = malloc(n * sizeof(int));
    if (arr == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    int *unique = malloc(n * sizeof(int));
    if (unique == NULL) {
        free(arr);
        printf("Memory allocation failed.\n");
        return 1;
    }
    int uniqueCount = 0;

    for (int i = 0; i < n; i++) {
        int current = arr[i];
        int found = 0;
        for (int j = 0; j < uniqueCount; j++) {
            if (unique[j] == current) {
                found = 1;
                break;
            }
        }
        if (!found) {
            unique[uniqueCount++] = current;
        }
    }

    printf("Array after removing duplicates (%d unique elements):\n", uniqueCount);
    for (int i = 0; i < uniqueCount; i++) {
        printf("%d ", unique[i]);
    }
    printf("\n");

    free(arr);
    free(unique);
    return 0;
}
