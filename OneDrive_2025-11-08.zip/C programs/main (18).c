/******************************************************************************
 
WAPC to input the temperature in Celsius and output it in Fahrenheit.


*******************************************************************************/

#include <stdio.h>
#include <math.h>

int main()
{
    float C,F;
    printf("Enter temperature in Celsius:");
    scanf("%f",&C);
    F= (C*9/5) + 32 ;
    printf("\nThe temperature in Fahrenheit is:%f",F);
    
   

    return 0;
}