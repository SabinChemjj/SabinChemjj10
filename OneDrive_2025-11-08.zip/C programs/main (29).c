/******************************************************************************
WAPC to input three unique integers. Find the maximum value.
*******************************************************************************/

#include <stdio.h>
#include <math.h>

int main()
{
   int n1,n2,n3;
   printf("Enter three numbers:");
   scanf("%d %d %d",&n1, &n2, &n3);
   if(n1>n2 && n1>n3){
       printf("\nThe maximum value is:%d",n1);
   }
   else if(n2>n3 && n2>n1){
       printf("\n The maximum value is:%d",n2);
   }
   else{
       printf("\n The maximum value is:%d",n3);
   }
   
    
    return 0;
}
